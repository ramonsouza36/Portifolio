using Microsoft.EntityFrameworkCore;

namespace Dados
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationDbContext>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
            OnCreated();
        }

        
    }

    public class IdentityDbContext<T>
    {
    }
}