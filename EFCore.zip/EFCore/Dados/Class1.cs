﻿using System;

namespace Dados
{
    public class Class1
    {
    }
}
