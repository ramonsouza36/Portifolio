﻿using System;

namespace Dominio
{
    public class Class1
    {
    }
}
