namespace Dominio.Entidades
{

    public class Categoria
    {
        
        public int Id {get; set;}

        public string Nome {get;set;}

        public Categoria Categorias {get; set;} 
        
    }    
}